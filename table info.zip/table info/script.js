var vardas = $('#vardas');
var pavarde = $('#pavarde');
var amzius = $('#amzius');
var hobis = $('#hobis')
var btn = $('#prideti');
var table = $('table');

$(document).ready(function(){
	btn.on('click', function() {
		if (vardas.val() && pavarde.val() && amzius.val() && hobis.val()) {
			table.append("<tr><td>" + vardas.val() + "</td><td>" + pavarde.val() + "</td><td>" + amzius.val() + "</td><td>" + hobis.val() + "</td></tr>");
			vardas.val("");
			pavarde.val("");
			amzius.val("");
			hobis.val("");
		}
		else {
			alert('iveskite duomenis');
		}
	})
});