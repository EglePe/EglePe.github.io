<?php

function spalvos() {

 $langeliai[]='zalia';
 for ($i = 1; $i <= 36; $i++){
  $spalva = 'raudona';
   if ($i % 2 == 0) {
    $spalva = 'juoda';
  }
    $langeliai[] = $spalva;  
 } 
   return $langeliai;
}


function ridenk() {
 return rand(0, 36);
}

$spalvos = spalvos();
$ridenimas = ridenk();


echo "Jusu skaicius: ".$ridenimas."<br >";
echo "Jusu spalva: ".$spalvos[$ridenimas]."<br >";
//var_dump($spalvos);

?>