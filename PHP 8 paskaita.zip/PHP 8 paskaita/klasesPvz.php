<?php
class Rulete
{
   public $langeliai;

  
   public function __construct()
   {
     $langeliai[] = 'zalia'; 
     for ($i = 1; $i<=36; $i++) {
        $spalva = "raudona";
        if ($i % 2 == 0) {
          $spalva = "juoda";
        }
        $langeliai[] = $spalva;
      }
      $this->langeliai = $langeliai;

   } 


   public function getLangeliai()
   {
     echo $this->langeliai;
   }


   public function ridenk()
   {
     return rand(0, 36);
   } 
}


class Kita extends Rulete
{
  public $langeliai;

  public function funkcija()
  {
        echo "cia yra Kita klases funkcija";
  }
}

//$obj = new Kita();
//$obj->funkcija();

$rulete = new Rulete();
$laimingasSkaicius = $rulete->ridenk();

echo "Laimingas skaicius yra ".$laimingasSkaicius." ".$rulete->langeliai[$laimingasSkaicius]."<br/>";

$rulete->getLangeliai();

?>