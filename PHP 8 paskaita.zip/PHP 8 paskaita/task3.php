<?php
$masyvas = array(5, 6, 4, -3, 0, 8, -1);
echo array_sum($masyvas)."<br />";

$max=ciklasd($masyvas);
  echo "didziausias masyvo skaicius: ".$max."<br/>";

$min=ciklasm($masyvas);
echo "maziausias masyvo skaicius: ".$min."<br/>";

function ciklasd ($masyvas){
  for ($i=0; $i<count($masyvas); $i++) {
      if (!isset($maxNum)|| $masyvas[$i]>$maxNum){
         $maxNum=$masyvas[$i];
      }
  }
  return $maxNum;
}

function ciklasm ($masyvas){
  for ($i=0; $i<count($masyvas); $i++) {
      if (!isset($minNum)|| $masyvas[$i]<$minNum){
         $minNum=$masyvas[$i];
      }
  }
  return $minNum;
}

?>
