<?php
$masyvas = array(5, 6, 4, -3, 0, 8, -1);
echo array_sum($masyvas)."<br />";

function ciklasMax ($masyvas){
  for ($i=0; $i<count($masyvas); $i++) {
      if (!isset($maxNum)|| $masyvas[$i]>$maxNum){
         $maxNum=$masyvas[$i];
      }
  }
  return $maxNum;
}

function ciklasMin ($masyvas){
  for ($i=0; $i<count($masyvas); $i++) {
      if (!isset($minNum)|| $masyvas[$i]<$minNum){
         $minNum=$masyvas[$i];
      }
  }
  return $minNum;
}

$max = ciklasMax($masyvas);
  echo "didziausias masyvo skaicius: ".$max."<br/>";

$min = ciklasMin($masyvas);
echo "maziausias masyvo skaicius: ".$min."<br/>";

?>
