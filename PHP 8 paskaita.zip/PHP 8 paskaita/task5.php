<?php

/*panaudoti funkcijas strpos(), strlen(), str_replace(),
explode(), trim(), str_replace(), strtoupper(), strtolower().*/

$sakinys = "Kiek „Kvadrato“ yra lietuviškos meno žaidimo aikštelės kvadratiniame metre?";

//srtpos()
$findMe = "žaidimo";
$pos = strpos($sakinys, $findMe);
echo "Position of word \"žaidimo\" was found at position: ".$pos;

//strlen()
echo "The sentence above has: ".strlen($sakinys)." symbols";

//str_replace()
echo str_replace("meno", "kūrybos", "Kiek „Kvadrato“ yra lietuviškos meno žaidimo aikštelės kvadratiniame metre?");

//explode()
print_r(explode(" ",$sakinys));

//trim()
echo $sakinys . "<br>";
echo trim($sakinys, "K?e");

//strtoupper()
echo strtoupper($sakinys);

//strtolower()
echo strtolower($sakinys);


/*susikurti masyva, kurio reiksmes susigalvoti zodziai. Ppanaudoti implode(). */

$masyvas = array("Kiek", "„Kvadrato“", "yra", "lietuviškos", "meno", "žaidimo", "aikštelės", "kvadratiniame", "metre?");
echo implode(" ", $masyvas);