<?php

$a = 1 ;
$b = 4 ;
$c = 4 ;

function myMath($a, $b, $c) {

$D = $b * $b - 4 * $a * $c;
 if ($D < 0) {
 return false;
  }

 else {
  $x1 = (-$b + sqrt($D))/(2*$a);
  $x2 = (-$b - sqrt($D))/(2*$a);
  return array($x1,  $x2);
  }
}

$atsakymas = (myMath($a, $b, $c));
//var_dump($atsakymas);

if (!$atsakymas) {
    echo "sprendiniu nera";
} else {
 echo "sprendinai yra ".$atsakymas[0]." ir ".$atsakymas[1];
}

?>