<?php
/*PIRMAS MASYVAS
$masyvas = array(9, 4, 3, -2, 0, 1, 56, 14, -17);

 foreach($masyvas as $value) {
    echo ($daugyba[] = $value *3)."<br >";}*/


/*ANTRAS MASYVAS
/$masyvas = array(15, -3, 0, 4, 89);*/


//DVIMATIS MASYVAS
$divamatisMasyvas = array
(
array(9, 4, 3, -2, 0, 1, 56, 14, -17),
array(15, -3, 0, 4, 89)
);

	foreach($divamatisMasyvas as $value){
		foreach($value as $key => $item){
			echo ($item*3)."</br>";}
	}
		

?>
