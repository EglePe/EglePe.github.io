<?php


class Pool {


	//PLYTELES FUNKCIJA
	public function plytele(){
	 $i = 2;
	 $a = 7;
	 $plytelesPlotis = $i * $a;
	  return $plytelesPlotis;
	}

	//BASEINO FUNKCIJA
	public function baseinas() {
	$i = 200;
	$p = 150;
	$a = 15;
	 
	$baseinoPlotis = $i * $p + ($i * $a) * 2 + ($p * $a) *2;
	  return $baseinoPlotis;	  
	}


	public function apskaiciavimas()  {
	//APSKAICIAVIMAS, KIEK REIKES PLYTELIU?
	$baseinas = $this->baseinas($baseinoPlotis);
	$plytele = $this->plytele($plytelesPlotis);

	$plyteliuKiekis = $baseinas / $plytele;
	return ceil($plyteliuKiekis);
	}

}


$base = new Pool();
$galutinis = $base->apskaiciavimas();
$plyPlotis = $base->plytele();
$basPlotis = $base->baseinas();


//var_dump($galutinis);


echo "Plyteles plotis: ".$plyPlotis."<br />";
echo "Baseino bendras plotis yra: ".$basPlotis."<br />";
echo "Is viso reikes ".$galutinis." plyteliu.";


?>