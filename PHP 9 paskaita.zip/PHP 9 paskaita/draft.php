<?php

/*$masyvas = array(9, 4, 3, -2, 0, 1, 56, 14, -17);

 foreach($masyvas as $value) {
    echo ($arr[] = $value *3)."<br >";}*/


class Mas {
  
public $masyvas = array(9, 4, 3, -2, 0, 1, 56, 14, -17);
  
	public function multiply(){
  
	 foreach($this->masyvas as $value) {
    
	  return $ats[] = $value * 3; }
	}

}

$classMas = new Mas();
$result = $classMas->multiply();

echo "Masyvo elementai padauginti is 3 sugeneruoja tokius atsakymus: ".$result;

?>