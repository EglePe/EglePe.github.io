<?php 
/* Yra 3 vokai. Vienas is ju yra pilnas kiti du tusti.
Pasirenkamas vienas vokas. Is dvieju likusiu voku vienas yra atidaromas ir parodomas, kad jis tuscias
Tada jums pasiulo keisti likusi voka i ta, kuri jus turite. 
1. Jus sutinkate apsikeisti.
2. Pasiliekate sau pasirinkta voka.
3. apsimoka labiau keistis, ar pasilikti pasirinkta, ar tai neturi itakos?
4. Ar apsioketu keistis vokais, jei laimingi vokai butu 2 ir isimamas vokas butu laimingas?
*/

function isimkVoka($vokai, $renkamesVoka)
{
	   //kolkas nezinom ar pasirinkome laiminga ar ne.
   	//einam per kiekviena voka
   	foreach ($vokai as $key => $value) {
      //echo "vokai ".$key."-ojo elemento reiksme yra ".($value?"true":"false")."<br />";
      //mums reikia viena voka isimti t.y. isimti ta, kurio nepasirinkome ir ta, kuris yra tuscias
      if ($key != $renkamesVoka && $value == false) {
        return $key;
      }
   }
}

function renkamesKita($vokai, $isimtas, $pasirinktas) {
   foreach ($vokai as $key => $value) {
        if ($key != $isimtas && $key != $pasirinktas){
           return $key;
        }
   }
}

//funkcija voku skaiciavimui.
function vokuFunkcija($vokai) 
{
   
   //vienas vokas laimingas. Tarkime, kad ji priskiriame atsitiktinai.
   $laimingasVokas = rand(1,3);
   $vokai[$laimingasVokas] = true;
 
   //pasirenkame atsitiktinai voka
   $renkamesVoka = rand(1,3);

   $isimamVoka = isimkVoka($vokai, $renkamesVoka);
   return [
    'laimingas' => $laimingasVokas,
    'pasirinktas' => $renkamesVoka,
    'isimtas' => $isimamVoka
   ];
}


//Visi tusti vokai is pradziu
$vokai = [
  1 => false, 
  2 => false, 
  3 => false 
];

$bandymuKiekis = 1000000;
$visoAtspejom = 0;
for($i=0; $i<$bandymuKiekis; $i++) {
  $returner = vokuFunkcija($vokai);
  if ($returner["pasirinktas"] == $returner["laimingas"]) {
    $visoAtspejom += 1;    
  }
}


echo "Bandymu Kiekis ".$bandymuKiekis."<br />";
echo "Is ju atspejom ".$visoAtspejom."<br />";
echo "Atspejimo procentas ". $visoAtspejom / $bandymuKiekis * 100 ."<br />";

 $visoAtspejom = 0;
for($i=0; $i<$bandymuKiekis; $i++) {
  $returner = vokuFunkcija($vokai);
  $returner["pasirinktas"] = renkamesKita($vokai, $returner["isimtas"], $returner["pasirinktas"]);
  if ($returner["pasirinktas"] == $returner["laimingas"]) {
    $visoAtspejom += 1;    
  }
}   

echo "Jei renkames kita:<br />";
echo "Bandymu Kiekis ".$bandymuKiekis."<br />";
echo "Is ju atspejom ".$visoAtspejom."<br />";
echo "Atspejimo procentas ". $visoAtspejom / $bandymuKiekis * 100;

?>