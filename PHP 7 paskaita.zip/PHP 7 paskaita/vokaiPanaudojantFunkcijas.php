<?php 
/* Yra 3 vokai. Vienas is ju yra pilnas kiti du tusti.
Pasirenkamas vienas vokas. Is dvieju likusiu voku vienas yra atidaromas ir parodomas, kad jis tuscias
Tada jums pasiulo keisti likusi voka i ta, kuri jus turite. 
1. Jus sutinkate apsikeisti.
2. Pasiliekate sau pasirinkta voka.
3. apsimoka labiau keistis, ar pasilikti pasirinkta, ar tai neturi itakos?
*/

function isimkVoka($vokai, $renkamesVoka)
{
   foreach ($vokai as $key => $item) {
      //mums reikia viena voka isimti t.y. isimti ta, kurio nepasirinkome ir ta, kuris yra tuscias
      if ($key != $renkamesVoka && $item == false) {
              $isimamVoka = $key;
      }
   }

   return $isimamVoka;
}

//funkcija voku skaiciavimui.
function vokuFunkcija() 
{
   //Visi tusti vokai is pradziu
   $vokai = [
      1 => false, 2 => false, 3 => false 
   ];
      
   //vienas vokas laimingas. Tarkime, kad ji priskiriame atsitiktinai.
   $laimingasVokas = rand(1,3);
   $vokai[$laimingasVokas] = true;
  
   //pasirenkame atsitiktinai voka
   $renkamesVoka = rand(1,3);
  
   //kolkas nezinom ar pasirinkome laiminga ar ne.
   //einam per kiekviena voka
  
   $isimamVoka = isimkVoka($vokai, $renkamesVoka);
   return [
    'laimingas' => $laimingasVokas,
    'pasirinktas' => $renkamesVoka,
    'isimtas' => $isimamVoka
   ];
}

$returner = vokuFunkcija();

echo "Is triju voku laimingas vokas yra ".$returner["laimingas"]." <br />";
echo "Mes pasirinkome voka ".$returner["pasirinktas"]." <br />";
echo "Isimamas vokas buvo ",$returner["isimtas"]." <br />";
?>