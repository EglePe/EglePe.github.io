<?php 
/* Yra 3 vokai. Vienas is ju yra pilnas kiti du tusti.
Pasirenkamas vienas vokas. Is dvieju likusiu voku vienas yra atidaromas ir parodomas, kad jis tuscias
Tada jums pasiulo keisti likusi voka i ta, kuri jus turite. 
1. Jus sutinkate apsikeisti.
2. Pasiliekate sau pasirinkta voka.
3. apsimoka labiau keistis, ar pasilikti pasirinkta, ar tai neturi itakos?
4. Ar apsimoka keistis vokais, jei laimingi vokai butu 2 ir isimamas vokas butu laimingas?
*/

//Visi tusti vokai is pradziu
$vokai = [
  1 => false, 2 => false, 3 => false 
];
  
//vienas vokas laimingas. Tarkime, kad ji priskiriame atsitiktinai.
$laimingasVokas = rand(1,3);
$vokai[$laimingasVokas] = true;

//pasirenkame atsitiktinai voka
$renkamesVoka = rand(1,3);

//kolkas nezinom ar pasirinkome laiminga ar ne.
//einam per kiekviena voka
foreach ($vokai as $key => $value) {
  //mums reikia viena voka isimti t.y. isimti ta, kurio nepasirinkome ir ta, kuris yra tuscias
  if ($key != $renkamesVoka && $value == false) {
      $isimamVoka = $key;
  }
}

echo "Is triju voku laimingas vokas yra ".$laimingasVokas." <br />";
echo "Mes pasirinkome voka ".$renkamesVoka." <br />";
echo "Isimamas vokas buvo ",$isimamVoka." <br />";
?>