//pirmas variantas

<?php
$vokai = array("vokas1" => "tuscias", "vokas2" => "10 euru",  "vokas3" => "tuscias");

if ($vokai[0]) {
echo "vokas tuscias";
}

elseif ($vokai[1]) {
  echo "Laimejote 10 euru";
}

elseif ($vokai[2]) {
 echo "vokas tuscias";
}

echo "Pasirinkimas"." ".$vokai["vokas2"];

?>

/antras variantas

<?php
$vokai = array(1 => "tuscias", 2 => "10 euru",  3 => "tuscias");

if ($vokai[0]) {
echo "vokas tuscias";
}

elseif ($vokai[1]) {
  echo "Pasirinkote 2 voka, ar norite keistis? ";
 }

elseif ($vokai[2]) {
 echo "vokas tuscias";
}

$result = rand (1, 3);
echo $vokai[$result];
?>




//trecias variantas

<?php
//visi tusti vokai is pradziu
$vokai = [
1 => false, 2 => false, 3 => false
];
  
//vienas vokas laimingas. Tarkime, kad ji priskiriame atsitiktinai.
$laimingasVokas = rand (1,3);
$vokai[$laimingasVokas] = true;

//pasirenkame atsitiktinai voka
$renkamesVoka = rand (1, 3);

//dar nezinome ar pasirinkome laiminga ar ne. Toliau einam per kiekviena voka
foreach ($vokai as $key => $item) {
  
//reikia 1 voka isimti, t.y. isimti ta, kurio nepasirinkome ir ta, kuris yra tuscias
if ($key != $renkamesVoka && $item == false) {
$isimamVoka = $key;

}}

echo "Laimingas vokas yra ".$laimingasVokas."<br />";
echo "Mes pasirinkome voka".$renkamesVoka."<br />";
echo "Isimamas vokas buvo".$isimamVoka."<br />";

?>