var names = ["Jon Snow", "Cersei Lannister", "Daenerys Targaryen", "Theon Greyjoy", "Tyrion Lannister", "Arya Stark"];
var dydis = names.length;
console.log('Stark family members', names[0], names[dydis -1]);

function myFunction() {

    var numeris = prompt("Please enter number between 1 and " + dydis);
    if (numeris) {
      // paversti 'numeris'i skaiciu Number(numeris)
      numeris = Number(numeris);
      // susirandam varda
      console.log(names[numeris - 1]);
      var name = (names[numeris - 1]);


      document.getElementById("demo").innerHTML =
        "the" + " number " + numeris + " name" + " is " + name;
    }
  }