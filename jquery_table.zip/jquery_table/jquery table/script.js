var vardas = $('#vardas');
var pavarde = $('#pavarde');
var amzius = $('#amzius');
var btn = $('#prideti');
var table = $('table');

$(document).ready(function(){
	btn.on('click', function() {
		if (vardas.val() && pavarde.val() && amzius.val()) {
			table.append("<tr><td>" + vardas.val() + "</td><td>" + pavarde.val() + "</td><td>" + amzius.val() + "</td></tr>");
			vardas.val("");
			pavarde.val("");
			amzius.val("");
		}
		else {
			alert('iveskite duomenis');
		}
	})
});
